package com.psc.lovemyself.domain.findmyself.enums;

public enum Category {
    REVIEW,
    EVENT,
    AWARENESS,
    PROJECT,
    INSPIRATION,
    INSIGHT,
    FRAMEWORK,
    STUDY
}
