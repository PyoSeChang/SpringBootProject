package com.psc.lovemyself.domain.findmyself.idea;

import jakarta.persistence.Entity;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@NoArgsConstructor
@SuperBuilder
public class Inspiration extends Idea {
}
